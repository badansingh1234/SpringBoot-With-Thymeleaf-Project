package com.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductManagementCrudAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductManagementCrudAppApplication.class, args);
	}

}
