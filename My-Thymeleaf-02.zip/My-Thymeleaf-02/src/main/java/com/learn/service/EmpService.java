package com.learn.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.learn.entity.Employee;
import com.learn.repository.EmpRepository;

@Service
public class EmpService implements EmpIterface {
	
	@Autowired
	private EmpRepository empRepository;

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return empRepository.findAll();
	}
	@Override
	public void save(Employee employee) {
		// TODO Auto-generated method stub
		empRepository.save(employee);
	}
	@Override
	public Employee getById(Long id) {
		// TODO Auto-generated method stub
		Optional<Employee> optional = empRepository.findById(id);
        Employee employee = null;
        if (optional.isPresent())
            employee = optional.get();
        else
            throw new RuntimeException(
                "Employee not found for id : " + id);
        return employee;
	}
	@Override
	public void deleteViaId(long id) {
		// TODO Auto-generated method stub
		empRepository.deleteById(id);
	}
	
	
}
