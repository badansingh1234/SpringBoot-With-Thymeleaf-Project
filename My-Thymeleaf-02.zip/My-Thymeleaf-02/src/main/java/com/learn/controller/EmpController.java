package com.learn.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.learn.entity.Employee;
import com.learn.service.EmpService;

@Controller
public class EmpController {
	
	@Autowired
	private EmpService empService;
	
	@GetMapping("/")
    public String viewHomePage(Model model) {
        model.addAttribute("allemplist", empService.getAllEmployee());
        return "index";
    }
	
	@GetMapping("/addnew")
    public String addNewEmployee(Model model) {
        Employee employee = new Employee();
        model.addAttribute("employee", employee);
        return "newemployee";
    }
 
    @PostMapping("/save")
    public String saveEmployee(@ModelAttribute("employee") Employee employee) {
    	empService.save(employee);
        return "redirect:/";
    }
	
    @GetMapping("/showFormForUpdate/{id}")
    public String updateForm(@PathVariable(value = "id") long id, Model model) {
        Employee employee = empService.getById(id);
        model.addAttribute("employee", employee);
        return "update";
    }
 
    @GetMapping("/deleteEmployee/{id}")
    public String deleteThroughId(@PathVariable(value = "id") long id) {
        empService.deleteViaId(id);
        return "redirect:/";
 
    } 
	
	//--------------------------------------------------------------------
	@RequestMapping(value = "/show",method = RequestMethod.GET)
	public String  show(Model model) {
		Employee employee = new Employee();
		employee.setName("Badan Singh");
		employee.setEmail("sbadan49@gmail.com");
		employee.setPhoneNo("8307152871");
		employee.setAddress("Mathura");
		model.addAttribute("myEmp",employee);
		return "showvar";
	}
	// ------------------------------------------------------------------
	
	

}
