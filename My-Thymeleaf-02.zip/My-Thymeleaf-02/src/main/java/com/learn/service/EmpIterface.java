package com.learn.service;

import java.util.List;

import com.learn.entity.Employee;

public interface EmpIterface {
	
	List<Employee> getAllEmployee();
    void save(Employee employee);
    Employee getById(Long id);
    void deleteViaId(long id);

}
